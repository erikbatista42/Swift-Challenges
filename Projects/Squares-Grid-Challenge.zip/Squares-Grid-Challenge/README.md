# Game-Starter-Empty

Empty SpriteKit project for MOB 1.1

This is an empty SpriteKit project that contains the minimum needed to get started with SpriteKit. 
